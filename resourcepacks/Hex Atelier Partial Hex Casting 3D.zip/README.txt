Hex Atelier partial Hex Casting 3D — pass 36, 2026-10-31

Derived from Hex Casting 3D 1.0.0 (gok6mBsU) by Viktoria_Ntro, MIT.
Source ZIP SHA-512: 3b6fe4e14017db1b79698ef3aa4b7c895a4f84eab7bfa945f1125fbbeff75831b73b7123743e09c35abb1b0fb83d99596ec66806922f45f07f0a6887abae257c
Original blockstates and block-item wrappers: Hex Casting 0.11.4, MIT,
https://github.com/FallingColors/HexMod/tree/v0.11.4

Models and changed texture sheets are relocated into hex_atelier_hc3d.
Blockstates select those models. Stateless ordinary items use MODEFITE 1.0.3
display_context: gui/fixed use the original model; other contexts use HC3D.
Block items use their relocated block geometry in every context.
No original item model or texture path is replaced; stateful items receive
no MODEFITE definition. The Patchouli guide book is left unchanged.
No original HC3D archive, unused variants, pack icon or unrelated assets.

See the two included MIT notices. Disable this resource pack to reverse it.
